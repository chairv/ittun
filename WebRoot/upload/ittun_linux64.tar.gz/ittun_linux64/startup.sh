./bin/ngrok -config ./bin/ngrok.cfg -subdomain test 8080
